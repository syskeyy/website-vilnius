<!DOCTYPE html>
<html>
<head>
	<title>My Website</title>
</head>
<body>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="about.php">About</a></li>
		<li><a href="contact.php">Contact</a></li>
	</ul>