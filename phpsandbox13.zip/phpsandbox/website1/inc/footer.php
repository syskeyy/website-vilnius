<footer>
		<p>Mywebsite &copy; 2017</p>
	</footer>
</body>
</html>