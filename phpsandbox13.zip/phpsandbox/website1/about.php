<?php require 'inc/header.php'; ?>
	<h1>About</h1>
<?php require 'inc/footer.php'; ?>